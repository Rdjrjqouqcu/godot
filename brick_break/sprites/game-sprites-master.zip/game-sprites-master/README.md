# Free game sprites

A library of Free game assets to prototype your games.

It's easy to find open source sprites with a particular art style online but there are few sets dedicated to prototyping.

This repository is a collection of simple assets you can use to focus on what matters the most in your prototypes: the code and game mechanics.

## License

Everything here is under the [ CC0 - public domain ](https://creativecommons.org/publicdomain/zero/1.0/) license.
